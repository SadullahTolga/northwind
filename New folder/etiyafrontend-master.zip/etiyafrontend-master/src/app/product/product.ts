export interface Product{
    id:number;
    categoryId:number;
    name:string;
    unitPrice:number;
    unitsInStock:number;
    quantityPerUnit:string;
}