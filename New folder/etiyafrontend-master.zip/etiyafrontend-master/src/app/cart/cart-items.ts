import { CartItem } from './cart-item';

export const CartItems: CartItem[] = [];
